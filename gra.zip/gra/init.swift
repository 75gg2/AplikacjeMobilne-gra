//
//  init.swift
//  gra
//
//  Created by Kamil Gargula on 14/09/2022.
//

import Foundation

func loadActions()->Void{
    Action(
        key:"Dom",
        endpoints: ["Autobus": "A",
                    "Zadanie": "Z"],
        onLoad:{
            print("Ranek. Słyszysz budzik, lecz jesteś niewyspany.")
            print("Naciśnij")
              
        }
    )
}
