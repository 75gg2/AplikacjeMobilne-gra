//
//  Action.swift
//  swift
//
//  Created by Kamil Gargula on 14/09/2022.
//

import Foundation


class Action{
    var onLoad:()->();
    var key: String;
    var endpoints: [String:String];

    init(key:String, endpoints: [String:String], onLoad:@escaping ()->Void){
        self.key = key;
        self.endpoints = endpoints;
        self.onLoad = onLoad;
        AddThisPageOnInit(key:key)
    }
    func printAndReadActions()->Void{
//        for e in endpoints{
//
//        }
    }
    func setEndpoint(endpoint:String) -> Void{
        setPage(actionName: self.endpoints[endpoint]!);
    }
    func setPage(actionName:String) -> Void{
        actions[actionName]!.onLoad();
    }
    func AddThisPageOnInit(key:String) -> Void{
        actions[key] = self
    }
}
