//
//  main.swift
//  gra
//
//  Created by Kamil Gargula on 14/09/2022.
//

import Foundation
var actions: [String:Action] = [:];
loadActions()
actions.first!.value.onLoad()
